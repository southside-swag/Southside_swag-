SOUTHSIDE_SWAG WEBSITE
=======================

Open index.html in a browser to preview the site.

Files:
- index.html
- collection-mockup.png

Before publishing:
1. Add your real product prices and photos.
2. Connect the contact form to an email/form service.
3. Add your WhatsApp, Instagram and payment/order links.
4. Upload the folder to a web host such as GitHub Pages, Netlify or another hosting provider.
